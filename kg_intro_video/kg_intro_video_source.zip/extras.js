'use strict';
// ======================= 片头 -11–0 =======================
function intro() {
  const T = -11; // local u = t - T
  const s = G(L.main), h = D(L.html, 0, 0, W, H, 'layer'), o = G(L.over);
  for (const g of [s, o]) { g._tb = 1; g.style.transformBox = 'view-box'; g.style.transformOrigin = '960px 540px'; }
  for (const g of [s, h, o]) { A(g, T, .9, { o: [0, 1] }, 'lin'); A(g, -.95, .7, { o: [1, 0], s: [1, 1.04] }, 'lin'); }

  // background knowledge-graph network (decorative, slow drift)
  let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const pts = [];
  while (pts.length < 26) {
    const a = rnd() * Math.PI * 2, r = 0.7 + rnd() * 0.45;
    const x = 960 + Math.cos(a) * 900 * r, y = 560 + Math.sin(a) * 470 * r;
    if (x > 250 && x < 1670 && y > 230 && y < 740) continue;
    if (y < 120 || y > 980 || x < 40 || x > 1880) continue;
    pts.push({ x, y, ph: rnd() * 6.28, sp: .25 + rnd() * .35, r: 4 + rnd() * 5, t: T + .2 + rnd() * 2.6 });
  }
  const edges = [];
  pts.forEach((p, i) => { const d = pts.map((q, j) => [Math.hypot(p.x - q.x, p.y - q.y), j]).filter(e => e[1] !== i).sort((a, b) => a[0] - b[0]); for (const [dist, j] of d.slice(0, 2)) if (dist < 380 && !edges.some(e => (e[0] === j && e[1] === i))) edges.push([i, j]); });
  const net = G(s); net.style.opacity = .55;
  const eEls = edges.map(([i, j]) => { const l = S('line', { stroke: C.teal, 'stroke-width': 1.2, opacity: .45 }, net); hidden(l); show(l, Math.max(pts[i].t, pts[j].t) + .3, .6); return [l, i, j]; });
  const nEls = pts.map(p => { const c = S('circle', { r: p.r, fill: C.tealL }, net); c.style.filter = `drop-shadow(0 0 6px ${C.teal})`; hidden(c); show(c, p.t, .5); return c; });
  FNS.push(t => {
    if (t > 1) return;
    const P = pts.map(p => [p.x + Math.sin(t * p.sp + p.ph) * 14, p.y + Math.cos(t * p.sp * .8 + p.ph) * 10]);
    nEls.forEach((c, k) => { c.setAttribute('cx', P[k][0].toFixed(1)); c.setAttribute('cy', P[k][1].toFixed(1)); });
    eEls.forEach(([l, i, j]) => { l.setAttribute('x1', P[i][0].toFixed(1)); l.setAttribute('y1', P[i][1].toFixed(1)); l.setAttribute('x2', P[j][0].toFixed(1)); l.setAttribute('y2', P[j][1].toFixed(1)); });
  });

  // title block
  const c = D(h, 0, 262, W, null, 'ctr', '<span class="chap">接入方案介绍 · 约 2 分钟</span>'); fadeIn(c, T + .5, .6, 14);
  const tt = D(h, 0, 318, W, null, 'ctr ititle', '数据中台只读接入<span class="acc">知识图谱</span>'); A(tt, T + .8, .9, { o: [0, 1], y: [26, 0], s: [.96, 1] });
  const st = D(h, 0, 424, W, null, 'ctr isub', '保留原始数据和现有指标查询，在中台之外增加关联查询能力'); fadeIn(st, T + 1.6, .6, 14);
  const au = D(h, 0, 486, W, null, 'ctr aud', '适合 <span class="st na">业务人员</span><span class="st na">数据分析人员</span><span class="st na">接入开发人员</span>'); fadeIn(au, T + 2.3, .6, 12);

  // three-step idea
  const cards = [
    ['#9DB7DD', '数据中台', '原样保留 · 只读提供数据', 4.0],
    [C.teal, '外部知识图谱', '新增 · 保存对象和关系', 6.2],
    [C.orange, '联合查询', '图谱找关联 · 中台给数值', 7.6]
  ];
  cards.forEach(([col, t1, t2, at], i) => {
    const x = 320 + i * 450;
    const d = D(h, x, 580, 380, 112, 'card icard', `<b>${t1}</b><span>${t2}</span>`); d.style.borderLeft = `5px solid ${col}`;
    A(d, T + at, .55, { o: [0, 1], y: [24, 0] });
    if (i < 2) { const a = arrow(o, `M ${x + 392} 636 H ${x + 438}`, C.sub, { w: 3 }); drawA(a, T + cards[i + 1][3] - .25, .3); }
  });
}

// ======================= 片尾 120–133 =======================
function outro() {
  const T = 120;
  const s = G(L.main), h = D(L.html, 0, 0, W, H, 'layer'), o = G(L.over);
  sceneFX(s, h, o, T, 9999);
  const c = D(h, 96, 48, null, null, 'chap', '回顾'); fadeInX(c, T + .1);
  const a = D(h, 96, 96, null, null, 'h1', '不改中台，也能看清关联'); fadeInX(a, T + .25);
  const b = D(h, 96, 158, null, null, 'h2', '图谱找关系 · 中台给数值'); fadeInX(b, T + .45);
  const items = [
    ['#9DB7DD', '1', '中台只读', ['原始数据、表结构不修改', '指标口径与访问权限不变'], 1.1],
    [C.teal, '2', '图谱在外', ['对象、关系、ID 对应和待核记录', '都保存在中台之外'], 3.1],
    [C.orange, '3', '联合查询', ['图谱负责找关联对象和指标', '数值仍由中台原接口返回'], 5.2]
  ];
  const cs = items.map(([col, n, ttl, lines, at], i) => {
    const d = D(h, 150 + i * 560, 370, 500, 300, 'card scard', `<div class="top" style="background:${col}"></div><div class="n" style="color:${col};border-color:${col}">${n}</div><b>${ttl}</b>${lines.map(l => `<span>${l}</span>`).join('')}`);
    A(d, T + at, .6, { o: [0, 1], y: [30, 0] });
    return d;
  });
  // end card
  for (const el of [a, b, c, ...cs]) A(el, T + 7.5, .5, { o: [1, 0] }, 'lin');
  const e1 = D(h, 0, 330, W, null, 'ctr etitle', '数据中台只读接入<span class="acc">知识图谱</span>'); A(e1, T + 7.8, .6, { o: [0, 1], y: [20, 0] });
  const e2 = D(h, 0, 440, W, null, 'ctr', '<span class="notice">接入方案示意 · 实际接口需按中台现有能力适配</span>'); A(e2, T + 8.2, .6, { o: [0, 1], s: [.95, 1] });
  const e3 = D(h, 0, 540, W, null, 'ctr aud', '片中公司、矿山、ID 均为虚构示例，指标数值仅作占位'); fadeIn(e3, T + 9.0, .5, 10);
  const e4 = D(h, 0, 640, W, null, 'ctr thanks', '感谢观看'); fadeIn(e4, T + 10.4, .6, 12);
}

// ---------- chapter tracker ----------
function buildTracker() {
  const names = ['需求背景', '整体架构', 'ID对应', '关系构建', '联合查询', '新增数据', '如何开始'];
  const SC = [0, 15, 35, 55, 75, 95, 110, 120];
  const tr = D(L.hud, 0, 100, null, null, 'tracker', names.map((n, i) => `<span class="tk"><b>${i + 1}</b>${n}</span>`).join(''));
  const bx = boxOf(tr); tr.style.left = (1824 - bx.w) + 'px';
  const dx = 960 - (1824 - bx.w / 2), dy = 790 - (100 + bx.h / 2);
  hidden(tr); A(tr, -2.0, .5, { o: [0, 1] }, 'lin'); A(tr, 119.8, .5, { o: [1, 0] }, 'lin');
  A(tr, -99, .001, { x: [dx, dx], y: [dy, dy], s: [1.45, 1.45] });
  A(tr, -.45, .95, { x: [dx, 0], y: [dy, 0], s: [1.45, 1] }, 'io');
  const tks = [...tr.querySelectorAll('.tk')];
  FNS.push(t => {
    let cur = -1; for (let i = 0; i < 7; i++) if (t >= SC[i] - .25 && t < SC[i + 1] - .25) cur = i;
    tks.forEach((k, i) => { k.classList.toggle('on', i === cur); k.classList.toggle('done', cur >= 0 && i < cur); });
  });
}

// ---------- fade from / to black ----------
function buildFades() {
  const f1 = D(L.hud, 0, 0, W, H, 'blk'); A(f1, -11, .7, { o: [1, 0] }, 'lin');
  const f2 = D(L.hud, 0, 0, W, H, 'blk'); hidden(f2); A(f2, 132.2, .8, { o: [0, 1] }, 'lin');
}
