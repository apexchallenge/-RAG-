#!/usr/bin/env python3
"""Fit 9 narration segments (intro + 7 scenes + outro) to their windows, calibrate captions
from real speech pauses, and mix onto the rendered video.
usage: mix9.py prep <voice_dir> <work_dir>         -> fitted wavs + caps_override.js
       mix9.py mix  <work_dir> <video.mp4> <out.mp4>
Timeline: main time t in [-11, 133]; video time = t + 11.
"""
import json, os, re, subprocess, sys

OFF = 11.0
WINDOWS = [(-11, 0), (0, 15), (15, 35), (35, 55), (55, 75), (75, 95), (95, 110), (110, 120), (120, 133)]
LEAD, TAIL = 0.35, 0.3
HERE = os.path.dirname(os.path.abspath(__file__))


def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit(f"FAILED: {' '.join(cmd)}\n{r.stderr[-1500:]}")
    return r.stdout + r.stderr


def dur(p):
    return float(run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", p]).strip().splitlines()[0])


def narr_chunks():
    src = open(os.path.join(HERE, "scenes.js"), encoding="utf-8").read()
    block = src[src.index("const NARR = ["):src.index("];", src.index("const NARR = ["))]
    rows = re.findall(r"\[(-?\d+), (\d+), \[(.*?)\]\]", block)
    out = []
    for a, b, inner in rows:
        out.append((float(a), float(b), re.findall(r"'([^']*)'", inner)))
    return out


def nchars(s):
    return len(re.findall(r"[一-龥A-Za-z0-9]", s))


def pauses(path):
    log = run(["ffmpeg", "-hide_banner", "-i", path, "-af", "silencedetect=n=-38dB:d=0.16", "-f", "null", "-"])
    st = [float(x) for x in re.findall(r"silence_start: ([\d.]+)", log)]
    en = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", log)]
    return list(zip(st, en))


def prep(voice_dir, work):
    os.makedirs(work, exist_ok=True)
    chunks = narr_chunks()
    assert len(chunks) == 9, len(chunks)
    caps, report = [], []
    for i, ((w0, w1), (_, _, ch)) in enumerate(zip(WINDOWS, chunks)):
        src = next(os.path.join(voice_dir, f"s{i}{e}") for e in (".mp3", ".wav") if os.path.exists(os.path.join(voice_dir, f"s{i}{e}")))
        trim = os.path.join(work, f"trim{i}.wav")
        sr = "silenceremove=start_periods=1:start_threshold=-50dB:start_silence=0.03"
        run(["ffmpeg", "-y", "-loglevel", "error", "-i", src, "-af", f"{sr},areverse,{sr},areverse", "-ar", "48000", "-ac", "2", trim])
        d0 = dur(trim)
        budget = (w1 - w0) - LEAD - TAIL
        speed = max(1.0, min(1.3, d0 / budget))
        fit = os.path.join(work, f"fit{i}.wav")
        run(["ffmpeg", "-y", "-loglevel", "error", "-i", trim, "-af", f"atempo={speed:.4f}", "-ar", "48000", "-ac", "2", fit])
        d = dur(fit)
        report.append(f"s{i}: {d0:.2f}s -> {d:.2f}s (budget {budget:.2f}, x{speed:.3f})")
        start = w0 + LEAD
        # caption boundaries snapped to real pauses
        n = [nchars(c) for c in ch]
        tot = sum(n)
        ps = [((a + b) / 2) for a, b in pauses(fit) if a > 0.2 and b < d - 0.1]
        bounds, cum, last = [], 0, 0.0
        for k in range(len(ch) - 1):
            cum += n[k]
            est = d * cum / tot
            cands = [p for p in ps if abs(p - est) < 1.3 and p > last + 0.6]
            b = min(cands, key=lambda p: abs(p - est)) if cands else est
            bounds.append(b); last = b
        edges = [0.0] + bounds + [d + 0.25]
        for k, c in enumerate(ch):
            caps.append({"t0": round(start + edges[k], 3), "t1": round(start + edges[k + 1], 3), "text": re.sub(r"[，。；：、]$", "", c)})
        report.append("   bounds " + ", ".join(f"{b:.2f}" for b in bounds))
    with open(os.path.join(HERE, "caps_override.js"), "w", encoding="utf-8") as f:
        f.write("window.CAPS_OVERRIDE = " + json.dumps(caps, ensure_ascii=False) + ";\n")
    json.dump(caps, open(os.path.join(work, "caps.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("\n".join(report))


def mix(work, video, out):
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-i", video]
    for i in range(9):
        cmd += ["-i", os.path.join(work, f"fit{i}.wav")]
    parts = []
    for i, (w0, _) in enumerate(WINDOWS):
        ms = int(round((w0 + LEAD + OFF) * 1000))
        parts.append(f"[{i + 1}:a]adelay={ms}|{ms}[a{i}]")
    fc = ";".join(parts) + ";" + "".join(f"[a{i}]" for i in range(9)) + "amix=inputs=9:normalize=0,apad,loudnorm=I=-16:TP=-1.5:LRA=11[aout]"
    cmd += ["-filter_complex", fc, "-map", "0:v", "-map", "[aout]", "-c:v", "copy", "-c:a", "aac", "-b:a", "160k", "-ar", "48000", "-shortest", "-movflags", "+faststart", out]
    run(cmd)
    print("mixed", out)


if __name__ == "__main__":
    if sys.argv[1] == "prep":
        prep(sys.argv[2], sys.argv[3])
    else:
        mix(sys.argv[2], sys.argv[3], sys.argv[4])
