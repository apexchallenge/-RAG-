// usage: node render.mjs stills 1,2,3 outdir   |   node render.mjs video out.mp4 start end [fps]   |   node render.mjs srt out.srt
import { createRequire } from 'module';
import { spawn } from 'child_process';
import fs from 'fs';
const require = createRequire(import.meta.url);
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const [mode, a1, a2, a3, a4] = process.argv.slice(2);
const browser = await chromium.launch({ args: ['--font-render-hinting=none', '--force-color-profile=srgb', '--disable-lcd-text'] });
const page = await browser.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 });
page.on('pageerror', e => console.error('PAGEERROR', e.message));
page.on('console', m => { if (m.type() === 'error') console.error('CONSOLE', m.text()); });
await page.goto('file:///home/claude/kgvideo/index.html');
await page.waitForFunction(() => window.__ready === true, null, { timeout: 30000 });
const seek = t => page.evaluate(t => window.__seek(t), t);

if (mode === 'stills') {
  fs.mkdirSync(a2, { recursive: true });
  for (const t of a1.split(',').map(Number)) { await seek(t); await page.screenshot({ path: `${a2}/t${t.toFixed(1).padStart(5, '0')}.png` }); }
} else if (mode === 'srt') {
  const caps = await page.evaluate(() => window.__caps);
  const f = s => { const ms = Math.round(s * 1000), h = Math.floor(ms / 3600000), m = Math.floor(ms / 60000) % 60, sec = Math.floor(ms / 1000) % 60, r = ms % 1000; return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')},${String(r).padStart(3, '0')}`; };
  fs.writeFileSync(a1, caps.map((c, i) => `${i + 1}\n${f(c.t0)} --> ${f(c.t1)}\n${c.text}\n`).join('\n'));
  fs.writeFileSync(a1.replace(/\.srt$/, '.json'), JSON.stringify(caps, null, 1));
} else if (mode === 'video') {
  const fps = +(a4 || 30), s0 = +a2, s1 = +a3, n = Math.round((s1 - s0) * fps);
  const ff = spawn('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', String(fps), '-c:v', 'mjpeg', '-i', '-', '-c:v', 'libx264', '-preset', 'medium', '-crf', '18', '-pix_fmt', 'yuv420p', '-r', String(fps), a1], { stdio: ['pipe', 'inherit', 'inherit'] });
  const t0 = Date.now();
  for (let i = 0; i < n; i++) {
    await seek(s0 + i / fps);
    const buf = await page.screenshot({ type: 'jpeg', quality: 93 });
    if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
    if (i % 300 === 0) console.log(`${a1}: ${i}/${n} ${((Date.now() - t0) / 1000).toFixed(0)}s`);
  }
  ff.stdin.end(); await new Promise(r => ff.on('close', r));
  console.log(`${a1}: done ${((Date.now() - t0) / 1000).toFixed(0)}s`);
}
await browser.close();
