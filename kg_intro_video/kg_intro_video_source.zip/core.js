'use strict';
// ---------- deterministic timeline core ----------
const W = 1920, H = 1080, NS = 'http://www.w3.org/2000/svg';
const FONT = "'Noto Sans CJK SC',sans-serif";
const MONO = "'DejaVu Sans Mono',monospace";
const C = {
  text: '#E8F0FA', sub: '#9DB2CC', dim: '#60779A',
  blue: '#3B82F6', blueL: '#8EC2FF', orange: '#F59E0B', orangeL: '#FFC46B',
  teal: '#2DD4BF', tealL: '#7FF0DF', green: '#22C55E', greenL: '#86EFAC',
  yellow: '#FACC15', yellowL: '#FDE68A', red: '#EF4444', redL: '#FCA5A5',
  purple: '#A78BFA', node: '#15304F', gray: '#94A3B8', comp: '#93C5FD'
};
const ANIMS = [], FNS = [];
let GROUPS = null, UID = 0, DEFS = null;
const L = {};

const E = {
  lin: p => p,
  out: p => 1 - Math.pow(1 - p, 3),
  in: p => p * p * p,
  io: p => p < .5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2,
  back: p => { const c1 = 1.5, c3 = c1 + 1; return 1 + c3 * Math.pow(p - 1, 3) + c1 * Math.pow(p - 1, 2); }
};

function A(el, t0, dur, props, ease) {
  if (props.s && el instanceof SVGElement && !el._tb) { el.style.transformBox = 'fill-box'; el.style.transformOrigin = 'center'; el._tb = 1; }
  for (const k in props) {
    const v = props[k];
    ANIMS.push({ el, k, t0, t1: t0 + Math.max(dur, 0.001), a: v[0], b: v[1], e: E[ease || 'out'] });
  }
  return el;
}
const fadeIn = (el, t, d = .5, dy = 18) => A(el, t, d, { o: [0, 1], y: [dy, 0] });
const fadeInX = (el, t, d = .5, dx = -24) => A(el, t, d, { o: [0, 1], x: [dx, 0] });
const show = (el, t, d = .35) => A(el, t, d, { o: [0, 1] }, 'lin');
const hide = (el, t, d = .35) => A(el, t, d, { o: [1, 0] }, 'lin');
const hidden = el => A(el, -1e6, .001, { o: [0, 0] });
function pop(el, t, d = .5) { A(el, t, d, { s: [.55, 1] }, 'back'); return A(el, t, d * .5, { o: [0, 1] }, 'lin'); }
function pulse(el, t, d = .7, k = 1.1) { A(el, t, d * .45, { s: [1, k] }, 'out'); A(el, t + d * .45, d * .55, { s: [k, 1] }, 'io'); return el; }
function drawA(a, t, d = .8) { return A(a.draw, t, d, { d: [0, 1] }, 'io'); }

function buildGroups() {
  GROUPS = new Map();
  for (const a of ANIMS) {
    let m = GROUPS.get(a.el); if (!m) { m = {}; GROUPS.set(a.el, m); }
    (m[a.k] || (m[a.k] = [])).push(a);
  }
  for (const m of GROUPS.values()) for (const k in m) m[k].sort((x, y) => x.t0 - y.t0);
}
function V(list, t) {
  let c = null;
  for (const a of list) { if (a.t0 <= t) c = a; else break; }
  if (!c) return list[0].a;
  const p = Math.min(1, Math.max(0, (t - c.t0) / (c.t1 - c.t0)));
  return c.a + (c.b - c.a) * c.e(p);
}
function setDash(el, d) {
  const len = el._len;
  el.style.strokeDasharray = `${len} ${len + 20}`;
  el.style.strokeDashoffset = len * (1 - d);
  if (el._head) {
    const p = el._path, L1 = Math.max(.01, len * d);
    const pt = p.getPointAtLength(L1), p0 = p.getPointAtLength(Math.max(0, L1 - 3));
    const ang = Math.atan2(pt.y - p0.y, pt.x - p0.x) * 180 / Math.PI;
    el._head.setAttribute('transform', `translate(${pt.x.toFixed(2)},${pt.y.toFixed(2)}) rotate(${ang.toFixed(2)})`);
    el._head.style.opacity = d > .03 ? 1 : 0;
  }
}
function seek(t) {
  if (!GROUPS) buildGroups();
  for (const [el, m] of GROUPS) {
    if (m.o) { const o = Math.max(0, Math.min(1, V(m.o, t))); el.style.opacity = o; el.style.visibility = o < .002 ? 'hidden' : ''; }
    if (m.x || m.y || m.s) {
      const x = m.x ? V(m.x, t) : 0, y = m.y ? V(m.y, t) : 0, s = m.s ? V(m.s, t) : 1;
      el.style.transform = `translate(${x.toFixed(2)}px,${y.toFixed(2)}px) scale(${s.toFixed(4)})`;
    }
    if (m.d) setDash(el, Math.max(0, Math.min(1, V(m.d, t))));
  }
  for (const f of FNS) f(t);
}

// ---------- SVG helpers ----------
function S(tag, at, p) {
  const e = document.createElementNS(NS, tag);
  if (at) for (const k in at) if (at[k] != null) e.setAttribute(k, at[k]);
  if (p) p.appendChild(e);
  return e;
}
const G = p => S('g', null, p);
function TX(p, x, y, s, o = {}) {
  const t = S('text', {
    x, y, 'font-size': o.size || 24, 'font-weight': o.weight || 400, fill: o.fill || C.text,
    'text-anchor': o.anchor || 'start', 'dominant-baseline': 'central', 'font-family': o.mono ? MONO : FONT,
    'letter-spacing': o.ls || null, 'writing-mode': o.wm || null
  }, p);
  t.textContent = s; return t;
}
// rich text: parts = [[str, fill, weight]]
function TXR(p, x, y, parts, o = {}) {
  const t = S('text', { x, y, 'font-size': o.size || 24, 'dominant-baseline': 'central', 'font-family': FONT, 'text-anchor': o.anchor || 'start' }, p);
  for (const [s, fill, wt] of parts) { const sp = S('tspan', { fill: fill || C.text, 'font-weight': wt || 400 }, t); sp.textContent = s; }
  return t;
}
const CV = document.createElement('canvas').getContext('2d');
function mw(s, size, wt = 400, mono = false) { CV.font = `${wt} ${size}px ${mono ? MONO : FONT}`; return CV.measureText(s).width; }
function chip(p, x, y, s, o = {}) {
  const size = o.size || 22, wt = o.weight || 500, h = o.h || Math.round(size * 1.75), px = o.px ?? 16;
  const ic = o.icon ? size * 1.05 : 0;
  const w = o.w || mw(s, size, wt, o.mono) + px * 2 + ic;
  const x0 = o.anchor === 'middle' ? x - w / 2 : o.anchor === 'end' ? x - w : x;
  const g = G(p);
  S('rect', { x: x0, y: y - h / 2, width: w, height: h, rx: o.r ?? h / 2, fill: o.fill || 'rgba(59,130,246,.16)', stroke: o.stroke || C.blue, 'stroke-width': o.sw || 1.5, 'stroke-dasharray': o.dash || null }, g);
  if (o.icon === 'lock') lockIcon(g, x0 + px + size * .4, y, size * .85, o.color || C.text);
  if (o.icon === 'check') checkIcon(g, x0 + px + size * .38, y, size * .8, o.color || C.text);
  TX(g, x0 + ic + (w - ic) / 2, y + 1, s, { size, weight: wt, fill: o.color || C.text, anchor: 'middle', mono: o.mono });
  g.w = w; g.x0 = x0; return g;
}
function lockIcon(p, x, y, s, col) {
  const g = G(p);
  S('rect', { x: x - s * .42, y: y - s * .08, width: s * .84, height: s * .6, rx: s * .1, fill: col }, g);
  S('path', { d: `M${x - s * .26},${y - s * .08} V${y - s * .3} A${s * .26},${s * .26} 0 0 1 ${x + s * .26},${y - s * .3} V${y - s * .08}`, fill: 'none', stroke: col, 'stroke-width': s * .12 }, g);
  return g;
}
function checkIcon(p, x, y, s, col) {
  return S('path', { d: `M${x - s * .38},${y} L${x - s * .1},${y + s * .28} L${x + s * .4},${y - s * .3}`, fill: 'none', stroke: col, 'stroke-width': s * .17, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, p);
}
function xIcon(p, x, y, s, col, w = 5) {
  const g = G(p);
  S('path', { d: `M${x - s},${y - s} L${x + s},${y + s} M${x + s},${y - s} L${x - s},${y + s}`, stroke: col, 'stroke-width': w, 'stroke-linecap': 'round' }, g);
  return g;
}
function node(p, x, y, r, label, o = {}) {
  const g = G(p), st = o.stroke || C.teal;
  const c = S('circle', { cx: x, cy: y, r, fill: o.fill || C.node, stroke: st, 'stroke-width': o.sw || 3 }, g);
  c.style.filter = `drop-shadow(0 0 ${o.glow ? 14 : 6}px ${st}66)`;
  TX(g, x, y, label, { size: o.size || 22, weight: 600, anchor: 'middle' });
  return g;
}
function hexNode(p, x, y, r, label, o = {}) {
  const g = G(p), pts = [];
  for (let i = 0; i < 6; i++) { const a = Math.PI / 3 * i; pts.push((x + r * Math.cos(a)).toFixed(1) + ',' + (y + r * Math.sin(a)).toFixed(1)); }
  const pg = S('polygon', { points: pts.join(' '), fill: o.fill || '#271E4D', stroke: o.stroke || C.purple, 'stroke-width': 3 }, g);
  pg.style.filter = `drop-shadow(0 0 6px ${C.purple}66)`;
  TX(g, x, y, label, { size: o.size || 22, weight: 600, anchor: 'middle' });
  return g;
}
function arrow(p, d, col, o = {}) {
  const g = G(p), w = o.w || 4;
  const path = S('path', { d, fill: 'none', stroke: col, 'stroke-width': w, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, g);
  if (o.glow) path.style.filter = `drop-shadow(0 0 5px ${col})`;
  const len = path.getTotalLength();
  let tgt = path;
  if (o.dash) {
    path.setAttribute('stroke-dasharray', o.dash);
    const id = 'mk' + (++UID);
    const m = S('mask', { id, maskUnits: 'userSpaceOnUse', x: 0, y: 0, width: W, height: H }, DEFS);
    const mp = S('path', { d, fill: 'none', stroke: '#fff', 'stroke-width': w + 14, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, m);
    path.setAttribute('mask', `url(#${id})`);
    tgt = mp;
  }
  tgt._len = len; tgt._path = path;
  if (o.head !== false) {
    const hs = o.hs || w * 3 + 6;
    tgt._head = S('path', { d: `M3,0 L${-hs},${-hs * .62} L${-hs * .6},0 L${-hs},${hs * .62} Z`, fill: col }, g);
  }
  setDash(tgt, 1);
  return { g, path, draw: tgt, len };
}
function flow(p, path, col, t0, t1, o = {}) {
  const n = o.n || 3, per = o.per || 1.5, r = o.r || 5.5, len = path.getTotalLength(), ds = [];
  for (let i = 0; i < n; i++) { const c = S('circle', { r, fill: col, opacity: 0 }, p); c.style.filter = `drop-shadow(0 0 6px ${col})`; ds.push(c); }
  FNS.push(t => {
    for (let i = 0; i < n; i++) {
      const c = ds[i];
      if (t < t0 || t > t1) { c.setAttribute('opacity', 0); continue; }
      const ph = (((t - t0) / per) + i / n) % 1, q = path.getPointAtLength(len * ph);
      c.setAttribute('cx', q.x.toFixed(1)); c.setAttribute('cy', q.y.toFixed(1));
      const e = Math.min(1, (t - t0) / .3, (t1 - t) / .3);
      c.setAttribute('opacity', (e * Math.min(1, ph * 8, (1 - ph) * 8)).toFixed(3));
    }
  });
}
function cylinder(p, cx, cy, w, h, col) {
  const rx = w / 2, ry = w * .17, top = cy - h / 2, bot = cy + h / 2, g = G(p);
  S('path', { d: `M ${cx - rx} ${top} V ${bot} A ${rx} ${ry} 0 0 0 ${cx + rx} ${bot} V ${top}`, fill: '#0D3540', stroke: col, 'stroke-width': 2.5 }, g);
  for (const f of [.33, .66]) { const yy = top + h * f; S('path', { d: `M ${cx - rx} ${yy} A ${rx} ${ry} 0 0 0 ${cx + rx} ${yy}`, fill: 'none', stroke: col, 'stroke-width': 1.5, opacity: .55 }, g); }
  S('ellipse', { cx, cy: top, rx, ry, fill: '#14505C', stroke: col, 'stroke-width': 2.5 }, g);
  return g;
}
function svgCard(p, x, y, w, h, title, dot = C.teal) {
  const g = G(p);
  S('rect', { x, y, width: w, height: h, rx: 14, fill: '#172A45', stroke: 'rgba(125,160,210,.4)', 'stroke-width': 1.5 }, g);
  S('line', { x1: x, y1: y + 47, x2: x + w, y2: y + 47, stroke: 'rgba(125,160,210,.25)' }, g);
  S('circle', { cx: x + 26, cy: y + 24, r: 6, fill: dot }, g);
  TX(g, x + 42, y + 24, title, { size: 22, weight: 600, fill: '#C9D8EA' });
  return g;
}

// ---------- iso plates ----------
const ISO = { kx: .87, ky: .28 };
function isoP(cx, cy, x, y) { return [cx + (x - y) * ISO.kx, cy + (x + y) * ISO.ky]; }
function plate(p, cx, cy, o = {}) {
  const w = o.w || 560, d = o.d || 180, th = o.th || 16, g = G(p);
  const a = isoP(cx, cy, -w / 2, -d / 2), b = isoP(cx, cy, w / 2, -d / 2), c = isoP(cx, cy, w / 2, d / 2), dd = isoP(cx, cy, -w / 2, d / 2);
  const P = arr => arr.map(q => q[0].toFixed(1) + ',' + q[1].toFixed(1)).join(' ');
  const dn = q => [q[0], q[1] + th];
  const st = o.stroke || '#7D9AC4';
  S('polygon', { points: P([dd, c, dn(c), dn(dd)]), fill: o.left || '#1D3150', stroke: st, 'stroke-width': 1.2, 'stroke-linejoin': 'round' }, g);
  S('polygon', { points: P([c, b, dn(b), dn(c)]), fill: o.right || '#16263F', stroke: st, 'stroke-width': 1.2, 'stroke-linejoin': 'round' }, g);
  const top = S('polygon', { points: P([a, b, c, dd]), fill: o.top || '#2A4366', stroke: st, 'stroke-width': 2, 'stroke-dasharray': o.dash || null, 'stroke-linejoin': 'round' }, g);
  g.P = { a, b, c, d: dd }; g.top = top; g.cx = cx; g.cy = cy; g.pts = P([a, b, c, dd]);
  return g;
}
function plateGlow(pl, col) {
  const e = S('polygon', { points: pl.pts, fill: col + '1A', stroke: col, 'stroke-width': 4, 'stroke-linejoin': 'round' }, pl);
  e.style.filter = `drop-shadow(0 0 10px ${col})`;
  hidden(e); return e;
}
function decoDB(pl) {
  const g = G(pl);
  for (let k = 0; k < 3; k++) { const y = 0 + k * 28, a = isoP(pl.cx, pl.cy, -10, y), b = isoP(pl.cx, pl.cy, 200, y); S('line', { x1: a[0], y1: a[1], x2: b[0], y2: b[1], stroke: '#A9C1E4', 'stroke-width': 2.2, opacity: .5 }, g); }
}
function decoGraph(pl) {
  const g = G(pl);
  const pts = [[0, 50], [100, 15], [180, 60], [80, 80], [220, 10]].map(q => isoP(pl.cx, pl.cy, q[0], q[1]));
  [[0, 1], [1, 2], [1, 3], [2, 4], [0, 3]].forEach(([i, j]) => S('line', { x1: pts[i][0], y1: pts[i][1], x2: pts[j][0], y2: pts[j][1], stroke: C.tealL, 'stroke-width': 1.6, opacity: .6 }, g));
  pts.forEach(q => S('ellipse', { cx: q[0], cy: q[1], rx: 7, ry: 4.5, fill: C.tealL, opacity: .9 }, g));
}

// ---------- HTML helpers ----------
function D(p, x, y, w, h, cls, html) {
  const d = document.createElement('div');
  if (cls) d.className = cls;
  const s = d.style; s.position = 'absolute'; s.left = x + 'px'; s.top = y + 'px';
  if (w) s.width = w + 'px'; if (h) s.height = h + 'px';
  if (html != null) d.innerHTML = html;
  p.appendChild(d); return d;
}
function boxOf(el) { const r = el.getBoundingClientRect(); return { x: r.left, y: r.top, w: r.width, h: r.height, cx: r.left + r.width / 2, cy: r.top + r.height / 2, r: r.right, b: r.bottom }; }
function tableHTML(title, cols, rows, ws) {
  const gt = ws.map(w => typeof w === 'number' ? w + 'px' : w).join(' ');
  let s = title ? `<div class="hd">${title}</div>` : '';
  s += `<div class="tr th" style="grid-template-columns:${gt}">${cols.map(c => `<span>${c}</span>`).join('')}</div>`;
  for (const r of rows) s += `<div class="tr" style="grid-template-columns:${gt}">${r.map(c => `<span>${c}</span>`).join('')}</div>`;
  return s;
}
const rowsOf = el => [...el.querySelectorAll('.tr:not(.th)')];
function typeText(el, str, t0, dur) {
  const chars = [...str];
  FNS.push(t => {
    const n = t < t0 ? 0 : Math.min(chars.length, Math.ceil((t - t0) / dur * chars.length));
    const s = chars.slice(0, n).join('');
    if (el._s !== s) { el.textContent = s; el._s = s; }
    el.classList.toggle('typing', t >= t0 - .3 && t < t0 + dur + .5);
  });
}
function hl(p, b, col, t0, t1, pad = 4) {
  const r = S('rect', { x: b.x - pad, y: b.y - pad, width: b.w + pad * 2, height: b.h + pad * 2, rx: 10, fill: col + '22', stroke: col, 'stroke-width': 2.5 }, p);
  A(r, t0, .35, { o: [0, 1] }, 'lin'); if (t1) A(r, t1, .4, { o: [1, 0] }, 'lin');
  return r;
}
function cursor(p, keys, clicks, tEnd) {
  const g = G(p);
  S('path', { d: 'M0,0 L0,36 L9.5,27.5 L16,42 L22.5,39 L16,25 L28,25 Z', fill: '#fff', stroke: '#0A1220', 'stroke-width': 2, 'stroke-linejoin': 'round' }, g);
  g.style.filter = 'drop-shadow(0 4px 5px rgba(0,0,0,.55))';
  A(g, keys[0][0], .25, { o: [0, 1] }, 'lin'); A(g, tEnd, .3, { o: [1, 0] }, 'lin');
  A(g, -1e6, .001, { x: [keys[0][1], keys[0][1]], y: [keys[0][2], keys[0][2]] });
  for (let i = 0; i < keys.length - 1; i++) { const [t0, x0, y0] = keys[i], [t1, x1, y1] = keys[i + 1]; A(g, t0, t1 - t0, { x: [x0, x1], y: [y0, y1] }, 'io'); }
  for (const [tc, x, y] of clicks) {
    const c = S('circle', { cx: x, cy: y, r: 26, fill: 'none', stroke: '#fff', 'stroke-width': 3 }, p);
    hidden(c); A(c, tc, .55, { o: [.9, 0], s: [.3, 1.5] }, 'out');
  }
  return g;
}
