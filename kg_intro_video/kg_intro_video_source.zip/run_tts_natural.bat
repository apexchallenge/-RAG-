@echo off
cd /d "%~dp0"
set "LOG=%~dp0tts_natural_run.log"
echo run %date% %time% > "%LOG%"
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
echo PY=[%PY%] >> "%LOG%"
where py >> "%LOG%" 2>&1
where python >> "%LOG%" 2>&1
if not defined PY (
  echo [ERROR] Python not found >> "%LOG%"
  type "%LOG%"
  pause
  exit /b 1
)
%PY% --version >> "%LOG%" 2>&1
echo Installing edge-tts ...
%PY% -m pip install --disable-pip-version-check edge-tts >> "%LOG%" 2>&1 || %PY% -m pip install --disable-pip-version-check -i https://pypi.tuna.tsinghua.edu.cn/simple edge-tts >> "%LOG%" 2>&1
echo Generating voices, please wait 1-2 minutes ...
set PYTHONIOENCODING=utf-8
%PY% "%~dp0tts_natural.py" >> "%LOG%" 2>&1
echo exit code %errorlevel% >> "%LOG%"
type "%LOG%"
echo.
pause
