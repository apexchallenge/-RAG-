'use strict';
// ---------- narration (captions) ----------
const NARR = [
  [-11, 0, ['这个视频用大约两分钟，', '讲清楚怎样在不改动数据中台的前提下，', '接入知识图谱，补上关联查询能力。', '我们分七步来看。']],
  [0, 15, ['数据中台里，公司、矿山和指标都已经能查。', '现在业务还想看清它们之间的关联，', '比如哪家公司运营哪些矿山。', '前提是，原有数据和业务流程都不改。']],
  [15, 35, ['做法是在中台之外加一套知识图谱，', '把对象和关系连成一张网。', '外部同步程序从中台只读获取，只取不改；', '在外部完成转换和ID对应，', '再写入Neo4j，一种专门存关系的图数据库，', '供查询服务和页面使用。']],
  [35, 55, ['同一座矿山，图谱里是MIN0001，', '中台里是M001。', '两个ID不必相同，用对应表连起来。', '程序先按可靠编号和已确认的对应自动匹配；', '拿不准的标为待核，', '人工确认后保存，以后直接复用。']],
  [55, 75, ['关系怎么来？', '中台已有的关系直接保留；', '字段含义明确的，比如“运营单位”，', '就按规则生成“运营”关系，', '并记下来源和审核状态。', '但要注意：名称相似，不能证明是同一对象；', '“关联”也不能直接当成“拥有”。']],
  [75, 95, ['查示例甲公司关联矿山2024年的锑产量：', '图谱找到矿山，给出中台对象ID和指标ID；', '再调用中台原指标接口，', '也就是原有取数通道，', '按原统计规则和权限返回数值。', '缺数显示“暂无数据”，无权限显示“无权限”。']],
  [95, 110, ['新增数据分两种。', '已有矿山新增年度数值，沿用原对象ID；', '中台出现新矿山，确认后由外部程序', '生成新图谱ID并保存对应，', '有明确依据再建立关系。']],
  [110, 120, ['先用四份CSV表格文件搭练习图谱，', '验收后换成真实数据，', '再接入只读接口和联合查询服务。']],
  [120, 133, ['回顾一下：中台只读提供数据，', '关系保存在外部图谱，', '数值仍由中台原接口返回。', '以上为接入方案示意，', '实际接口需按中台现有能力适配。']]
];
let CAPS = [];
function buildCaptions() {
  const list = [];
  for (const [a, b, chunks] of NARR) {
    const w0 = a + .3, w1 = b - .35;
    const n = chunks.map(c => (c.match(/[一-龥A-Za-z0-9]/g) || []).length);
    const tot = n.reduce((x, y) => x + y, 0);
    let t = w0;
    chunks.forEach((c, i) => { const d = (w1 - w0) * n[i] / tot; list.push({ t0: t, t1: t + d, text: c.replace(/[，。；：、]$/, '') }); t += d; });
  }
  if (Array.isArray(window.CAPS_OVERRIDE) && window.CAPS_OVERRIDE.length) { list.length = 0; list.push(...window.CAPS_OVERRIDE); }
  const box = D(L.hud, 960, 1004, null, null, 'cap');
  FNS.push(t => {
    const c = list.find(c => t >= c.t0 && t < c.t1 + .05);
    if (c) { if (box._s !== c.text) { box.textContent = c.text; box._s = c.text; } box.style.opacity = 1; }
    else box.style.opacity = 0;
  });
  CAPS = list; window.__caps = list;
}

// ---------- scene scaffold ----------
function sceneFX(s, h, o, t0, t1) {
  for (const g of [s, o]) { g._tb = 1; g.style.transformBox = 'view-box'; g.style.transformOrigin = '960px 540px'; }
  for (const g of [s, h, o]) {
    A(g, t0 - .3, .8, { o: [0, 1], s: [1.03, 1] }, 'io');
    if (t1 < 999) A(g, t1 - .35, .7, { o: [1, 0], s: [1, .985] }, 'io');
  }
}
function scene(t0, t1, chap, h1, h2) {
  const s = G(L.main), h = D(L.html, 0, 0, W, H, 'layer'), o = G(L.over);
  sceneFX(s, h, o, t0, t1);
  const c = D(h, 96, 48, null, null, 'chap', chap); fadeInX(c, t0 + .1);
  const a = D(h, 96, 96, null, null, 'h1', h1); fadeInX(a, t0 + .25);
  const b = D(h, 96, 158, null, null, 'h2', h2); fadeInX(b, t0 + .45);
  return { s, h, o, T: t0, c, a, b };
}
function term(sc, t0, t1, title, desc, x = 96, y = 872) {
  const d = D(sc.h, x, y, null, null, 'term', `<b>${title}</b><span>${desc}</span>`);
  fadeIn(d, t0, .45, 14); hide(d, t1, .35); return d;
}
const EXT = { top: '#103A46', left: '#0B2C36', right: '#08222B', stroke: C.teal, dash: '10 6' };
const CYS = [850, 728, 606, 484, 362];
const LNAMES = ['数据中台', '外部同步程序', '外部 Neo4j', '联合查询服务', '展示页面'];

// ======================= 第一幕 需求背景 0–15 =======================
function scene1() {
  const sc = scene(0, 15, '第一幕 · 需求背景', '指标已经能查', '下一步：看清对象之间的关联'); const { h, o } = sc;
  const fr = D(h, 110, 232, 1700, 712, 'frame', '<div class="frame-t">数据中台<em>现有系统 · 原始数据</em></div>'); fadeIn(fr, .15, .6, 10);
  const t1 = D(h, 170, 300, 470, null, 'card', tableHTML('公司表', ['公司ID', '公司名称'], [['<b class="mono">C001</b>', '示例甲公司']], [140, '1fr']));
  const t2 = D(h, 725, 300, 470, null, 'card', tableHTML('矿山表', ['矿山ID', '矿山名称'], [['<b class="mono">M001</b>', '示例甲矿山'], ['<b class="mono">M002</b>', '示例乙矿山']], [140, '1fr']));
  const t3 = D(h, 1280, 300, 470, null, 'card', tableHTML('指标目录', ['指标ID', '指标名称'], [['<b class="mono">I001</b>', '锑产量']], [140, '1fr']));
  fadeIn(t1, .3); fadeIn(t2, .7); fadeIn(t3, 1.1);
  const bt1 = boxOf(t1), bt2 = boxOf(t2);

  const q = D(h, 430, 566, 1060, 330, 'card ui', '<div class="bar"><i></i><i></i><i></i><span>指标查询 · 现有页面</span></div>');
  D(q, 40, 80, null, null, 'fl', '对象'); const i1 = D(q, 100, 80, 250, 54, 'inp');
  D(q, 380, 80, null, null, 'fl', '指标'); const i2 = D(q, 440, 80, 200, 54, 'inp');
  D(q, 670, 80, null, null, 'fl', '年份'); const i3 = D(q, 730, 80, 130, 54, 'inp');
  const bt = D(q, 890, 80, 130, 54, 'btn', '查询');
  D(q, 40, 176, null, null, 'fl', '结果');
  const p1 = D(q, 100, 192, 560, 24, 'ph'), p2 = D(q, 100, 232, 380, 24, 'ph'), tg = D(q, 690, 186, null, null, 'st na', '示意 · 非真实数值');
  fadeIn(q, 2.2, .6, 40);
  typeText(i1, '示例甲矿山', 2.8, .6); typeText(i2, '锑产量', 3.5, .4); typeText(i3, '2024', 4.0, .3);
  pulse(bt, 4.8, .3, .92);
  show(p1, 5.2, .3); show(p2, 5.4, .3); show(tg, 5.6, .3);
  cursor(o, [[2.6, 1480, 990], [4.6, 1385, 676], [5.0, 1385, 676], [5.9, 1560, 800]], [[4.8, 1385, 676]], 6.2);
  A(q, 6.4, .6, { o: [1, .32] }, 'lin');

  const a1 = arrow(o, 'M 520 300 C 600 236, 880 236, 960 300', C.blueL, { dash: '8 8', w: 3, head: false }); drawA(a1, 6.6, .9);
  const a2 = arrow(o, 'M 1075 300 C 1155 236, 1435 236, 1515 300', C.blueL, { dash: '8 8', w: 3, head: false }); drawA(a2, 7.0, .9);
  const qb = (x, y) => { const g = G(o); S('circle', { cx: x, cy: y, r: 21, fill: '#13294A', stroke: C.blueL, 'stroke-width': 2.5 }, g); TX(g, x, y + 1, '?', { size: 26, weight: 700, fill: C.blueL, anchor: 'middle' }); return g; };
  const b1 = qb(740, 253), b2 = qb(1295, 253); pop(b1, 7.4); pop(b2, 7.8);
  pulse(b1, 8.8, .8, 1.3);
  hl(o, bt1, C.blueL, 8.8, 11.2); hl(o, bt2, C.blueL, 8.8, 11.2);
  const lk = chip(o, 1790, 912, '原数据 · 原流程保持不变', { size: 21, icon: 'lock', fill: 'rgba(20,60,40,.9)', stroke: C.green, color: C.greenL, anchor: 'end' });
  pop(lk, 11.5); pulse(lk, 13.0, .7, 1.06);
}

// ======================= 第二幕 整体架构 15–35 =======================
function scene2() {
  const sc = scene(15, 35, '第二幕 · 整体架构', '中台只读提供数据', '关系存进中台之外的图谱'); const { s } = sc, T = 15;
  const cx = 860;
  const subs = ['继续提供数据 · 表结构与原始数据不修改', null, '图数据库 · 保存对象和关系', '组合图谱关系与中台指标', '查看关联对象和指标结果'];
  const tA = [.2, 1.2, 2.2, 3.2, 4.2], pl = [];
  for (let i = 0; i < 5; i++) {
    const p = plate(s, cx, CYS[i], i ? EXT : {}); pl.push(p);
    if (i === 0) decoDB(p); if (i === 2) decoGraph(p);
    A(p, T + tA[i], .7, { o: [0, 1], y: [60, 0] });
    const B = p.P.b, lg = G(s), col = i ? C.teal : '#9DB7DD';
    S('line', { x1: B[0] + 10, y1: B[1], x2: 1222, y2: B[1], stroke: col, 'stroke-width': 1.5, 'stroke-dasharray': '3 5' }, lg);
    S('circle', { cx: B[0], cy: B[1], r: 4.5, fill: col }, lg);
    TX(lg, 1240, B[1] - 14, LNAMES[i], { size: 30, weight: 700 });
    if (i === 0) lockIcon(lg, 1240 + mw(LNAMES[0], 30, 700) + 22, B[1] - 16, 22, '#9DB7DD');
    if (subs[i]) TX(lg, 1240, B[1] + 20, subs[i], { size: 20, fill: C.sub });
    fadeInX(lg, T + tA[i] + .35, .5, -20);
  }
  // brackets
  const br1 = arrow(s, 'M 1782 392 H 1800 V 830 H 1782', C.teal, { w: 2.5, head: false }); drawA(br1, T + 5.2, .8);
  const bt1 = TX(s, 1826, 611, '中台之外 · 新增', { size: 22, weight: 600, fill: C.tealL, anchor: 'middle', wm: 'vertical-rl' }); show(bt1, T + 5.8);
  const br2 = arrow(s, 'M 1782 872 H 1800 V 944 H 1782', '#9DB7DD', { w: 2.5, head: false }); drawA(br2, T + 5.4, .6);
  const bt2 = TX(s, 1826, 908, '原有', { size: 22, weight: 600, fill: '#C9D8EA', anchor: 'middle', wm: 'vertical-rl' }); show(bt2, T + 5.9);

  // build flow (left lane)
  const D0 = pl[0].P.d, D1 = pl[1].P.d, D2 = pl[2].P.d;
  const ar1 = arrow(s, `M ${D0[0] - 6} ${D0[1] + 4} H 482 V ${D1[1] + 10} H ${D1[0] - 10}`, C.blue, { w: 4.5, glow: true }); drawA(ar1, T + 6.4, .9);
  flow(s, ar1.path, C.blueL, T + 7.3, T + 20.5, { n: 3, per: 1.3 });
  const g1 = G(s);
  TX(g1, 462, 706, '只读获取', { size: 28, weight: 700, fill: C.blueL, anchor: 'end' });
  TX(g1, 462, 740, '授权接口 / 导出文件', { size: 20, fill: C.sub, anchor: 'end' });
  TX(g1, 462, 770, '对象 · 明确关系 · 指标目录', { size: 20, fill: C.blueL, anchor: 'end' });
  fadeInX(g1, T + 6.9, .5, 20);
  const rb = arrow(s, `M 510 ${D1[1] + 24} V ${D0[1] - 4}`, C.red, { w: 3, dash: '6 6' }); drawA(rb, T + 8.6, .5);
  const rx = xIcon(s, 510, (D1[1] + D0[1]) / 2 + 10, 11, C.red, 5); pop(rx, T + 9.1);
  const g2 = TX(s, 462, 810, '✕ 不回写中台', { size: 21, weight: 600, fill: C.redL, anchor: 'end' }); fadeInX(g2, T + 9.2, .4, 20);

  const ar2 = arrow(s, `M ${D1[0] - 6} ${D1[1] - 8} H 482 V ${D2[1] + 10} H ${D2[0] - 10}`, C.blue, { w: 4.5, glow: true }); drawA(ar2, T + 12.9, .9);
  flow(s, ar2.path, C.blueL, T + 13.8, T + 20.5, { n: 3, per: 1.3 });
  const g3 = G(s);
  TX(g3, 462, 600, '写入外部图谱', { size: 28, weight: 700, fill: C.blueL, anchor: 'end' });
  TX(g3, 462, 634, '对象 · 关系 · ID 对应', { size: 20, fill: C.sub, anchor: 'end' });
  fadeInX(g3, T + 13.1, .5, 20);

  // sync chips
  let x = 1240; const cy = pl[1].P.b[1] + 26;
  ['字段转换', 'ID 对应', '待核记录'].forEach((t, i) => { const c = chip(s, x, cy, t, { size: 19, fill: 'rgba(45,212,191,.12)', stroke: C.teal, color: C.tealL, px: 12 }); pop(c, T + 10.2 + i * .3, .45); x += c.w + 10; });
  const sv = TX(s, x + 6, cy, '均保存在中台之外', { size: 19, fill: C.sub }); show(sv, T + 11.2);

  // glows
  const gl2 = plateGlow(pl[2], C.teal); A(gl2, T + 14.0, .4, { o: [0, 1] }, 'lin'); A(gl2, T + 16.6, .5, { o: [1, 0] }, 'lin');
  for (const i of [3, 4]) { const g = plateGlow(pl[i], C.teal); A(g, T + 17.3, .4, { o: [0, 1] }, 'lin'); A(g, T + 19.0, .5, { o: [1, 0] }, 'lin'); }

  term(sc, T + 1.8, T + 6.0, '知识图谱', '把对象和对象之间的关系，连成一张网');
  term(sc, T + 7.0, T + 11.6, '只读', '只从中台取数据，不做任何修改');
  term(sc, T + 14.2, T + 17.6, 'Neo4j', '一种专门存储“关系”的图数据库');
}

// ======================= 第三幕 ID 对应 35–55 =======================
function scene3() {
  const sc = scene(35, 55, '第三幕 · ID 对应', '两个ID不必相同', '对应表连接，确认后复用'); const { s, h, o } = sc, T = 35;
  const lp = svgCard(s, 100, 300, 400, 330, '外部图谱 · Neo4j'); fadeIn(lp, T + .3);
  const nd = G(s); node(nd, 300, 462, 74, '示例甲矿山', { size: 23, glow: true });
  chip(nd, 300, 578, 'MIN0001', { mono: true, size: 22, fill: 'rgba(45,212,191,.14)', stroke: C.teal, color: C.tealL, anchor: 'middle' });
  pop(nd, T + .6); pulse(nd, T + 2.0, .8, 1.08);

  const rp = D(h, 1420, 300, 400, null, 'card', tableHTML('数据中台 · 矿山表', ['矿山ID', '矿山名称'], [['<b class="mono">M001</b>', '示例甲矿山'], ['<b class="mono">M002</b>', '示例乙矿山'], ['<b class="mono">M007</b>', '示例丙矿山<span class="st new sm">新</span>']], [120, '1fr']));
  fadeIn(rp, T + .5);
  const rr = rowsOf(rp); const bM001 = boxOf(rr[0]); show(rr[2], T + 13.6, .4);

  const mp = D(h, 560, 300, 800, null, 'card', tableHTML('ID 对应表 · 保存在中台之外', ['图谱ID', '中台ID', '匹配依据', '状态'], [
    ['<b class="mono">MIN0001</b>', '<b class="mono">M001</b>', '可靠编号一致', '<span class="st ok">✓ 已确认 · 自动</span>'],
    ['<b class="mono">MIN0002</b>', '<b class="mono">M002</b>', '已确认的对应', '<span class="st ok">✓ 已确认 · 复用</span>'],
    ['<span class="pend">待定</span>', '<b class="mono">M007</b>', '缺少可靠编号', '<span class="st warn">! 待核</span>']], [150, 120, 250, '1fr']));
  fadeIn(mp, T + 6.1);
  const mr = rowsOf(mp), mb = boxOf(mp), b1 = boxOf(mr[0]), b3 = boxOf(mr[2]);
  [9.8, 11.4, 14.0].forEach((t, i) => fadeInX(mr[i], T + t, .45, -20));

  hl(o, bM001, C.teal, T + 4.3, T + 9.6, 0);
  const l1 = arrow(s, `M 376 462 C 470 462, 480 ${b1.cy}, ${b1.x - 4} ${b1.cy}`, C.teal, { w: 3, head: false }); drawA(l1, T + 7.0, .7);
  const l2 = arrow(s, `M ${b1.r + 4} ${b1.cy} C ${b1.r + 30} ${b1.cy}, ${bM001.x - 30} ${bM001.cy}, ${bM001.x - 4} ${bM001.cy}`, C.teal, { w: 3, head: false }); drawA(l2, T + 7.6, .6);
  const hb1 = hl(o, b1, C.teal, T + 10.0, T + 12.4, 0);

  // modal (manual review)
  const dim = D(h, 80, 228, 1760, 730, 'dim'); hidden(dim); show(dim, T + 14.9, .3); hide(dim, T + 16.9, .3);
  const md = D(h, 560, 300, 800, 410, 'card modal', `<div class="hd"><i class="dot" style="background:#FACC15"></i>人工核对 · 待核记录</div><div class="cmp"><div class="col"><div class="ct">图谱候选</div><div class="kv"><i>名称</i>示例丙矿山</div><div class="kv"><i>图谱ID</i><b class="mono">MIN0003</b></div><div class="kv"><i>可靠编号</i><span class="miss">缺失</span></div></div><div class="col"><div class="ct">中台记录</div><div class="kv"><i>名称</i>示例丙矿山</div><div class="kv"><i>中台ID</i><b class="mono">M007</b></div><div class="kv"><i>可靠编号</i><span class="miss">缺失</span></div></div></div>`);
  const ok = D(md, 180, 326, 200, 54, 'btn ok', '确认对应'); D(md, 420, 326, 200, 54, 'btn gray', '不是同一对象');
  hidden(md); A(md, T + 14.9, .4, { o: [0, 1], s: [.94, 1] }); A(md, T + 16.9, .3, { o: [1, 0], s: [1, .96] });
  pulse(ok, T + 16.5, .3, .92);
  cursor(o, [[T + 15.2, 1250, 880], [T + 16.3, 842, 655], [T + 16.6, 842, 655], [T + 17.2, 1000, 780]], [[T + 16.5, 842, 655]], T + 17.3);

  const fix = D(mp, 0, b3.y - mb.y - 1.5, b3.w, b3.h, 'tr', ['<b class="mono">MIN0003</b>', '<b class="mono">M007</b>', '人工确认', '<span class="st ok">✓ 已确认 · 人工</span>'].map(c => `<span>${c}</span>`).join(''));
  fix.style.gridTemplateColumns = '150px 120px 250px 1fr'; fix.style.background = '#14273F';
  hidden(fix); show(fix, T + 17.2, .35); hl(o, b3, C.green, T + 17.3, T + 19.2, 0);

  // storage + reuse loop
  const cyl = G(s); cylinder(cyl, 870, 790, 120, 92, C.teal);
  TX(cyl, 1000, 772, '保存在中台之外', { size: 26, weight: 700 }); TX(cyl, 1000, 808, '下次同步直接复用', { size: 21, fill: C.sub });
  fadeIn(cyl, T + 17.8, .5);
  const loop = G(s); loop.style.transformBox = 'view-box'; loop.style.transformOrigin = '0 0';
  arrow(loop, 'M 870 680 A 108 108 0 1 1 772 836', C.tealL, { w: 3 });
  hidden(loop); show(loop, T + 18.2, .4);
  FNS.push(t => loop.setAttribute('transform', `rotate(${(Math.max(0, t - (T + 18.2)) * 110).toFixed(2)} 870 785)`));

  term(sc, T + 14.3, T + 17.4, '待核', '程序拿不准、需要人工确认的记录', 96, 872);
}

// ======================= 第四幕 关系构建 55–75 =======================
function scene4() {
  const sc = scene(55, 75, '第四幕 · 关系构建', '每条关系都要有依据', '名称相似≠同一对象，关联≠拥有'); const { s, h, o } = sc, T = 55;
  const ca = D(h, 100, 296, 480, 104, 'card src', '<div class="ic ok">✓</div><div><b>中台已有的关系</b><span>原样保留，不改写</span></div>'); fadeInX(ca, T + 1.6);
  const cb = D(h, 100, 420, 480, 104, 'card src', '<div class="ic gear">⚙</div><div><b>中台字段含义明确</b><span>按规则生成新关系</span></div>'); fadeInX(cb, T + 4.3);
  const n1 = node(o, 860, 410, 82, '示例甲公司', { size: 24, stroke: C.comp }), n2 = node(o, 1460, 410, 82, '示例甲矿山', { size: 24 });
  pop(n1, T + 4.6); pop(n2, T + 4.9);
  const e = arrow(o, 'M 946 410 H 1372', C.teal, { w: 4.5 }); drawA(e, T + 6.0, 1.0);
  const lb = chip(o, 1159, 410, '运营', { size: 24, weight: 700, fill: '#0F2E3A', stroke: C.teal, color: C.tealL, anchor: 'middle', px: 20 }); pop(lb, T + 7.5);
  const cn = arrow(o, 'M 584 472 C 760 545, 1060 545, 1150 436', C.blueL, { w: 2.5, dash: '6 6' }); drawA(cn, T + 7.7, .7);
  const cnl = TX(o, 860, 548, '按规则生成', { size: 19, fill: C.blueL, anchor: 'middle' }); show(cnl, T + 8.2);
  const ev = D(h, 1190, 520, 450, null, 'card ev', '<div class="ev-r"><i>来源</i>中台字段「运营单位」<em>示例字段</em></div><div class="ev-r"><i>生成方式</i>按规则生成</div><div class="ev-r"><i>审核状态</i><span class="st ok">✓ 已审核</span></div>');
  fadeIn(ev, T + 10.0);
  const ec = arrow(o, 'M 1175 430 L 1236 518', C.tealL, { w: 2, dash: '4 5', head: false }); drawA(ec, T + 9.8, .3);

  // warning 1
  const w1 = D(h, 180, 700, 740, 212, 'card warn'); fadeIn(w1, T + 12.5);
  const g1 = G(o); fadeIn(g1, T + 12.7);
  const s1 = '示例甲矿山', s2 = '示例甲矿山（二期）', pw1 = mw(s1, 24, 600) + 36, pw2 = mw(s2, 24, 600) + 36, gap = 120;
  let x0 = 550 - (pw1 + gap + pw2) / 2;
  chip(g1, x0, 776, s1, { size: 24, weight: 600, fill: C.node, stroke: C.teal, h: 50 });
  chip(g1, x0 + pw1 + gap, 776, s2, { size: 24, weight: 600, fill: C.node, stroke: C.teal, h: 50 });
  const ne = TX(o, x0 + pw1 + gap / 2, 772, '≠', { size: 60, weight: 700, fill: C.red, anchor: 'middle' }); pop(ne, T + 13.6);
  const wt1 = TX(o, 550, 862, '名称相似 ≠ 同一对象', { size: 30, weight: 700, fill: C.redL, anchor: 'middle' }); fadeIn(wt1, T + 14.2);

  // warning 2
  const w2 = D(h, 1000, 700, 740, 212, 'card warn'); fadeIn(w2, T + 16.9);
  const g2 = G(o); fadeIn(g2, T + 17.1);
  const q1 = '示例乙公司', q2 = '示例甲矿山', qw1 = mw(q1, 24, 600) + 36, qw2 = mw(q2, 24, 600) + 36, gap2 = 240;
  const xs = 1370 - (qw1 + gap2 + qw2) / 2;
  S('line', { x1: xs + qw1, y1: 776, x2: xs + qw1 + gap2, y2: 776, stroke: C.gray, 'stroke-width': 3, 'stroke-dasharray': '7 7' }, g2);
  chip(g2, xs, 776, q1, { size: 24, weight: 600, fill: C.node, stroke: C.comp, h: 50 });
  chip(g2, xs + qw1 + gap2, 776, q2, { size: 24, weight: 600, fill: C.node, stroke: C.teal, h: 50 });
  chip(g2, 1370, 776, '关联', { size: 20, fill: '#1E293B', stroke: C.gray, color: '#CBD5E1', anchor: 'middle' });
  const own = G(o); const oc = chip(own, 1370, 726, '拥有', { size: 22, weight: 700, fill: '#3A3010', stroke: C.yellow, color: C.yellowL, anchor: 'middle', px: 18 });
  A(own, T + 17.6, .5, { o: [0, 1], y: [-30, 0] });
  const ox = G(o); S('line', { x1: oc.x0 - 6, y1: 726, x2: oc.x0 + oc.w + 6, y2: 726, stroke: C.red, 'stroke-width': 4, 'stroke-linecap': 'round' }, ox);
  S('circle', { cx: oc.x0 + oc.w + 22, cy: 712, r: 15, fill: C.red }, ox); xIcon(ox, oc.x0 + oc.w + 22, 712, 6, '#fff', 3.5);
  pop(ox, T + 18.3, .4);
  const wt2 = TX(o, 1370, 862, '关联 ≠ 拥有', { size: 30, weight: 700, fill: C.redL, anchor: 'middle' }); fadeIn(wt2, T + 18.6);
}

// ======================= 第五幕 联合指标查询 75–95 =======================
function scene5() {
  const sc = scene(75, 95, '第五幕 · 联合指标查询', '图谱找关联', '数值仍由中台原接口返回'); const { s, h, o } = sc, T = 75;
  // Part A: query page
  const ui = D(h, 360, 292, 1200, 430, 'card ui', '<div class="bar"><i></i><i></i><i></i><span>关联指标查询 · 示意页面</span></div>');
  const F = [['对象', 40, 230, '示例甲公司'], ['范围', 356, 180, '关联矿山'], ['指标', 622, 160, '锑产量'], ['年份', 868, 120, '2024']];
  const tt = [.5, 1.2, 1.7, 2.1], td = [.6, .4, .3, .25];
  F.forEach(([lab, x, w, val], i) => { D(ui, x, 96, null, null, 'fl', lab); const inp = D(ui, x + 56, 96, w, 54, 'inp'); typeText(inp, val, T + tt[i], td[i]); });
  const bt = D(ui, 1064, 96, 104, 54, 'btn', '查询');
  D(ui, 40, 190, 1120, 200, 'hint', '结果将在这里显示');
  fadeIn(ui, T + .1, .5, 30); pulse(bt, T + 3.5, .3, .92); A(ui, T + 4.0, .4, { o: [1, 0], s: [1, .95] });
  cursor(o, [[T + 2.0, 1620, 860], [T + 3.3, 1478, 418], [T + 3.6, 1478, 418], [T + 3.95, 1520, 470]], [[T + 3.5, 1478, 418]], T + 3.9);

  // Part B: architecture with query flow
  const gs = G(s), gh = D(h, 0, 0, W, H, 'layer'), go = G(o);
  for (const g of [gs, gh, go]) { A(g, T + 4.2, .5, { o: [0, 1] }, 'lin'); A(g, T + 14.9, .4, { o: [1, 0] }, 'lin'); }
  const cx = 760, pl = CYS.map((cy, i) => plate(gs, cx, cy, i ? EXT : {}));
  decoDB(pl[0]); decoGraph(pl[2]); A(pl[1], -1e6, .001, { o: [.38, .38] });
  const subs = ['原指标接口 · 原统计规则 · 原权限', '本流程不经过', '只存关系和指标定义', '组合关系与指标', '发起查询 · 展示结果'];
  pl.forEach((p, i) => {
    const Dp = p.P.d, lg = G(gs), col = i === 0 ? '#9DB7DD' : C.teal;
    S('line', { x1: 414, y1: Dp[1], x2: Dp[0] - 8, y2: Dp[1], stroke: col, 'stroke-width': 1.5, 'stroke-dasharray': '3 5' }, lg);
    TX(lg, 400, Dp[1] - 16, LNAMES[i], { size: 26, weight: 700, anchor: 'end' });
    TX(lg, 400, Dp[1] + 16, subs[i], { size: 18, fill: C.sub, anchor: 'end' });
    if (i === 1) A(lg, -1e6, .001, { o: [.45, .45] });
  });
  const nh = chip(go, 402, pl[2].P.d[1] + 16, '只存关系和指标定义 · 不存历史数值', { size: 18, anchor: 'end', fill: '#2B1F08', stroke: C.orange, color: C.orangeL, h: 30, px: 12 });
  pop(nh, T + 6.1, .45);
  const nhl = plateGlow(pl[2], C.orange); A(nhl, T + 5.8, .3, { o: [0, .9] }, 'lin'); A(nhl, T + 8.0, .4, { o: [.9, 0] }, 'lin');

  const port = (i, u) => [cx + 322 - 157 * u, CYS[i] + 53 + 51 * u + 8];
  const lane = (i0, u0, i1, u1, x) => { const a = port(i0, u0), b = port(i1, u1); return `M ${(a[0] + 4).toFixed(1)} ${a[1].toFixed(1)} H ${x} V ${b[1].toFixed(1)} H ${(b[0] + 9).toFixed(1)}`; };
  const X1 = 1122, X2 = 1158, X3 = 1202, X4 = 1240;
  const ST = [
    { d: lane(4, .45, 3, 0, X1), t: 4.7, dur: .6, x: X1 },
    { d: lane(3, .95, 2, .35, X1), t: 5.6, dur: .6, x: X1 },
    { d: lane(2, .6, 3, .76, X2), t: 7.0, dur: .6, x: X2 },
    { d: lane(3, .56, 0, .3, X3), t: 8.9, dur: 1.2, x: X3 },
    { d: lane(0, .55, 3, .38, X4), t: 13.1, dur: 1.0, x: X4 },
    { d: lane(3, .18, 4, .2, X2), t: 14.1, dur: .55, x: X2 }
  ];
  ST.forEach((st, k) => {
    const a = arrow(gs, st.d, C.orange, { w: 4, glow: true }); drawA(a, T + st.t, st.dur);
    flow(gs, a.path, '#FFE0A8', T + st.t + .2, T + st.t + st.dur + 1.6, { n: 2, per: Math.max(.6, st.dur) });
    // badge at lane midpoint
    const seg = st.d.match(/V ([\d.]+)/)[1] * 1, y0 = st.d.match(/^M [\d.]+ ([\d.]+)/)[1] * 1, my = (seg + y0) / 2;
    const bg = G(go); S('circle', { cx: st.x, cy: my, r: 14, fill: C.orange, stroke: '#0B1730', 'stroke-width': 2 }, bg);
    TX(bg, st.x, my + 1, String(k + 1), { size: 18, weight: 700, fill: '#1A1204', anchor: 'middle', mono: true });
    pop(bg, T + st.t + st.dur * .6, .4);
  });
  // step callouts
  const CO = [
    [478, '①', '页面发起查询', 4.7], [512, '⑥', '返回页面：展示关系和结果', 14.1],
    [618, '②', '图谱查找关联矿山和指标定义', 5.6], [652, '③', '返回 M001、M002 · 指标ID I001', 7.0],
    [756, '④', '调用中台原指标接口（不经过同步程序）', 8.9], [790, '⑤', '中台按原统计规则和权限返回数值', 13.1]
  ];
  CO.forEach(([y, n, txt, t]) => { const tx = TXR(gs, 1282, y, [[n + ' ', C.orangeL, 700], [txt, C.text, 500]], { size: 22 }); fadeInX(tx, T + t, .4, 16); });
  term(sc, T + 11.1, T + 14.3, '接口', '系统之间约定好的取数通道');

  // Part C: result page
  const rs = D(h, 200, 262, 1520, 670, 'card', '<div class="hd"><i class="dot"></i>查询结果 · 示意</div>');
  hidden(rs); A(rs, T + 15.1, .5, { o: [0, 1], s: [.96, 1] });
  const gg = G(o); hidden(gg); show(gg, T + 15.4, .5);
  node(gg, 470, 600, 74, '示例甲公司', { size: 22, stroke: C.comp });
  node(gg, 800, 465, 62, '示例甲矿山', { size: 20 }); node(gg, 800, 735, 62, '示例乙矿山', { size: 20 });
  arrow(gg, 'M 537 570 L 742 490', C.teal, { w: 3.5 }); arrow(gg, 'M 537 630 L 742 710', C.teal, { w: 3.5 });
  chip(gg, 630, 520, '运营', { size: 18, fill: '#0F2E3A', stroke: C.teal, color: C.tealL, anchor: 'middle', h: 30, px: 10 });
  chip(gg, 630, 680, '运营', { size: 18, fill: '#0F2E3A', stroke: C.teal, color: C.tealL, anchor: 'middle', h: 30, px: 10 });
  const tb = D(h, 940, 350, 720, null, 'card', tableHTML('关联矿山 · 2024 年 · 锑产量', ['矿山', '年份', '指标', '数值'], [
    ['示例甲矿山', '2024', '锑产量', '<span class="ph"></span><em class="note">中台返回值 · 示意</em>'],
    ['示例乙矿山', '2024', '锑产量', '<span class="st na">暂无数据</span>']], [150, 90, 110, '1fr']));
  hidden(tb); show(tb, T + 15.5, .4);
  const tr = rowsOf(tb); fadeInX(tr[0], T + 15.9, .4); fadeInX(tr[1], T + 16.5, .4); pulse(tr[1].lastChild.firstChild, T + 17.0, .6, 1.15);
  const lockSvg = '<svg width="15" height="17" viewBox="0 0 16 18"><rect x="1" y="8" width="14" height="10" rx="2" fill="currentColor"/><path d="M4 8V5a4 4 0 0 1 8 0v3" fill="none" stroke="currentColor" stroke-width="2"/></svg>';
  const ins = D(h, 1180, 650, 480, 170, 'card', `<div class="hd"><i class="dot gray"></i>切换为无权限账号查看</div><div class="tr" style="grid-template-columns:150px 110px 1fr;height:66px"><span>示例甲矿山</span><span>锑产量</span><span><span class="st no">${lockSvg}无权限</span></span></div>`);
  hidden(ins); pop(ins, T + 17.6, .5);
}

// ======================= 第六幕 新增数据 95–110 =======================
function scene6() {
  const sc = scene(95, 110, '第六幕 · 新增数据', '已有对象沿用原ID', '新矿山确认后再建新ID'); const { s, h, o } = sc, T = 95;
  const pL = D(h, 90, 234, 850, 712, 'card', '<div class="hd"><i class="dot blue"></i>情况一 · 已有矿山新增年度数据</div>'); fadeIn(pL, T + .2);
  const pR = D(h, 980, 234, 850, 712, 'card', '<div class="hd"><i class="dot"></i>情况二 · 中台出现新矿山</div>'); fadeIn(pR, T + .4);
  // left
  const rc = D(h, 170, 306, 690, null, 'card', tableHTML('数据中台 · <b class="mono">M001</b> 示例甲矿山', ['年份', '锑产量', '说明'], [['2023', '<span class="ph"></span>', ''], ['2024', '<span class="ph"></span>', ''], ['2025', '<span class="ph"></span>', '<span class="st new">新增</span>']], [140, '1fr', 140]));
  fadeIn(rc, T + .8);
  const rr = rowsOf(rc); fadeInX(rr[2], T + 2.2, .5); hl(o, boxOf(rr[2]), C.blueL, T + 2.4, T + 5.4, 0);
  const a1 = arrow(o, 'M 515 586 V 634', C.blue, { w: 4 }); drawA(a1, T + 3.2, .4);
  const mc = chip(o, 515, 668, 'MIN0001 ↔ M001 · 沿用原对应', { size: 22, fill: 'rgba(30,58,100,.95)', stroke: C.blueL, anchor: 'middle' }); pop(mc, T + 3.6);
  const a2 = arrow(o, 'M 515 702 V 750', C.blue, { w: 4 }); drawA(a2, T + 4.4, .4);
  const nd = node(o, 420, 834, 64, '示例甲矿山', { size: 21 }); pop(nd, T + 4.8);
  const ic = chip(o, 520, 810, 'MIN0001', { mono: true, size: 20, fill: 'rgba(45,212,191,.12)', stroke: C.teal, color: C.tealL }); pop(ic, T + 5.1);
  const ok = chip(o, 520, 858, '图谱无需新建对象', { size: 20, icon: 'check', fill: 'rgba(34,197,94,.14)', stroke: C.green, color: C.greenL }); pop(ok, T + 5.4);
  // right
  const X = 1405;
  const s1 = D(h, 1060, 300, 690, 70, 'card step', '<b class="mono">M010</b><span>示例丁矿山</span><span class="st new">新增</span><small>中台新记录</small>'); fadeIn(s1, T + 6.1);
  const r1 = arrow(o, `M ${X} 376 V 426`, C.blue, { w: 4 }); drawA(r1, T + 6.6, .4);
  const rl = TX(o, X + 16, 401, '只读同步', { size: 20, fill: C.blueL }); show(rl, T + 6.7);
  const s2 = D(h, 1060, 436, 690, 66, 'card step', '<span>外部同步程序：对应表中无匹配</span><span class="st warn">! 待核</span>'); fadeIn(s2, T + 7.2);
  const r2 = arrow(o, `M ${X} 508 V 546`, C.blue, { w: 4 }); drawA(r2, T + 8.2, .35);
  const s3 = D(h, 1060, 556, 690, 66, 'card step', '<span>人工确认：<b>是新对象</b></span><span class="st ok">✓ 已确认</span>'); fadeIn(s3, T + 8.6);
  const r3 = arrow(o, `M ${X} 628 V 666`, C.blue, { w: 4 }); drawA(r3, T + 9.5, .35);
  const s4 = D(h, 1060, 676, 690, 66, 'card step', '<span>生成图谱ID <b class="mono">MIN0004</b></span><span class="sep">·</span><span>保存 <b class="mono">MIN0004 ↔ M010</b></span>'); fadeIn(s4, T + 9.8);
  const bL = arrow(o, `M ${X} 748 V 770 H 1235 V 798`, C.blue, { w: 3.5 }); drawA(bL, T + 12.3, .5);
  const bR = arrow(o, `M ${X} 748 V 770 H 1625 V 798`, '#7B8BA3', { w: 3.5, dash: '7 7' }); drawA(bR, T + 12.9, .5);
  const k1 = D(h, 1030, 806, 410, 124, 'card step2 ok2', '<b>有明确依据</b><div class="mini">示例甲公司<em>—运营→</em>示例丁矿山</div><small>来源：运营单位字段（示例）</small>'); fadeIn(k1, T + 12.6);
  const k2 = D(h, 1460, 806, 330, 124, 'card step2 gray2', '<b>暂无明确依据</b><div class="mini dash">暂不建立关系</div><small>补充依据后再处理</small>'); fadeIn(k2, T + 13.3);
}

// ======================= 第七幕 如何开始 110–120 =======================
function scene7() {
  const sc = scene(110, 120, '第七幕 · 如何开始', '先小样例验收', '再接真实数据和查询服务'); const { s, h, o } = sc, T = 110;
  const cyl = G(s); cylinder(cyl, 790, 470, 230, 170, C.teal);
  TX(cyl, 790, 640, 'Neo4j 练习库', { size: 24, weight: 700, anchor: 'middle', fill: C.tealL }); fadeIn(cyl, T + .15, .4);
  const files = [['实体.csv', '3 行 · 公司与矿山'], ['指标.csv', '1 行 · 锑产量'], ['关系.csv', '2 行 · 运营关系'], ['ID对应.csv', '3 行 · 图谱ID ↔ 中台ID']];
  files.forEach(([n, d], i) => {
    const y = 286 + i * 112;
    const c = D(h, 110, y, 340, 92, 'card csv', `<div class="fi">CSV</div><div><b>${n}</b><span>${d}</span></div>`); fadeInX(c, T + .1 + i * .08, .35);
    const t = T + .5 + i * .7, doc = G(o);
    S('rect', { x: 420, y: y + 24, width: 34, height: 44, rx: 5, fill: '#0F3B3A', stroke: C.teal, 'stroke-width': 2 }, doc);
    S('line', { x1: 427, y1: y + 38, x2: 447, y2: y + 38, stroke: C.tealL, 'stroke-width': 2 }, doc);
    S('line', { x1: 427, y1: y + 48, x2: 447, y2: y + 48, stroke: C.tealL, 'stroke-width': 2 }, doc);
    hidden(doc); A(doc, t, .12, { o: [0, 1] }, 'lin'); A(doc, t, .6, { x: [0, 790 - 437], y: [0, 450 - (y + 46)] }, 'io'); A(doc, t + .5, .12, { o: [1, 0] }, 'lin');
    const ck = chip(o, 466, y + 46, '已导入', { size: 16, icon: 'check', fill: 'rgba(34,197,94,.16)', stroke: C.green, color: C.greenL, h: 28, px: 10 }); pop(ck, t + .6, .35);
  });
  const gp = D(h, 1060, 272, 770, 452, 'card', '<div class="hd"><i class="dot"></i>练习图谱</div>'); fadeIn(gp, T + .3);
  const gg = G(o);
  const nC = node(gg, 1260, 420, 58, '示例甲公司', { size: 19, stroke: C.comp }), nM1 = node(gg, 1140, 630, 58, '示例甲矿山', { size: 19 }), nM2 = node(gg, 1400, 630, 58, '示例乙矿山', { size: 19 });
  [nC, nM1, nM2].forEach((n, i) => pop(n, T + 1.15 + i * .12));
  const nI = hexNode(gg, 1660, 525, 64, '锑产量', { size: 22 }); pop(nI, T + 1.85);
  const e1 = arrow(gg, 'M 1231 470 L 1172 575', C.teal, { w: 3.5 }), e2 = arrow(gg, 'M 1292 468 L 1366 578', C.teal, { w: 3.5 });
  drawA(e1, T + 2.5, .5); drawA(e2, T + 2.6, .5);
  const l1 = chip(gg, 1182, 522, '运营', { size: 17, fill: '#0F2E3A', stroke: C.teal, color: C.tealL, anchor: 'middle', h: 28, px: 10 });
  const l2 = chip(gg, 1350, 522, '运营', { size: 17, fill: '#0F2E3A', stroke: C.teal, color: C.tealL, anchor: 'middle', h: 28, px: 10 });
  pop(l1, T + 2.9); pop(l2, T + 3.0);
  const idc = [[1330, 420, '↔ C001', 'start'], [1140, 706, '↔ M001', 'middle'], [1400, 706, '↔ M002', 'middle'], [1660, 608, 'I001', 'middle']];
  idc.forEach(([x, y, t, an]) => { const c = chip(gg, x, y, t, { size: 16, mono: true, fill: 'rgba(148,163,184,.12)', stroke: '#64748B', color: '#CBD5E1', h: 26, px: 8, anchor: an }); pop(c, T + 3.2, .35); });
  const cnt = chip(o, 1430, 760, '实体 3 · 指标 1 · 关系 2', { size: 22, fill: 'rgba(45,212,191,.12)', stroke: C.teal, color: C.tealL, anchor: 'end' }); pop(cnt, T + 3.4);
  const acc = chip(o, 1446, 760, '导入验收', { size: 22, icon: 'check', fill: 'rgba(34,197,94,.16)', stroke: C.green, color: C.greenL }); pop(acc, T + 3.6);
  // roadmap
  const steps = ['① 小样例导入验收', '② 替换为真实中台数据', '③ 接入只读接口与联合查询服务'], ts = [3.9, 4.6, 6.4];
  const ws = steps.map(t => mw(t, 26, 600) + 44), gap = 72, tot = ws.reduce((a, b) => a + b) + gap * 2;
  let x = 960 - tot / 2; const y = 860;
  steps.forEach((t, i) => {
    const c = chip(o, x, y, t, { size: 26, weight: 600, h: 58, fill: 'rgba(16,58,70,.95)', stroke: C.teal }); pop(c, T + ts[i]);
    x += ws[i];
    if (i < 2) { const a = arrow(o, `M ${x + 12} ${y} H ${x + gap - 12}`, C.sub, { w: 3 }); drawA(a, T + ts[i] + .4, .3); x += gap; }
  });
}

// ---------- global HUD ----------
function buildHUD() {
  const b = document.createElement('div'); b.className = 'badge'; b.textContent = '虚构示例 · 公司、矿山与ID均为示例'; L.hud.appendChild(b); A(b, -.3, .5, { o: [0, 1] }, 'lin'); A(b, 119.8, .5, { o: [1, 0] }, 'lin');
  const ar = c => `<svg width="46" height="14"><path d="M2 7H34" stroke="${c}" stroke-width="4" stroke-linecap="round"/><path d="M44 7L31 1L34 7L31 13Z" fill="${c}"/></svg>`;
  const lg = D(L.hud, 1440, 1012, null, null, 'legend', `<span>${ar(C.blue)}构建流程</span><span>${ar(C.orange)}查询流程</span>`);
  hidden(lg); for (const [a, b] of [[21.4, 34.6], [79.4, 89.9], [95.4, 109.6]]) { A(lg, a, .5, { o: [0, 1] }, 'lin'); A(lg, b - .4, .4, { o: [1, 0] }, 'lin'); }
  buildCaptions();
}
function buildAll() { intro(); scene1(); scene2(); scene3(); scene4(); scene5(); scene6(); scene7(); outro(); buildHUD(); buildTracker(); buildFades(); }
